﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library
{
    interface IPoligono
    {
        double CalcularArea();

        double CalcularArea(double arg1, double arg2);

        double GetArea();

    }
}
